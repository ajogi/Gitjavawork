
class User
{
    private String name;
	private int complaintCount;
	
	public User(String name, int complaintCount) {
		super();
		this.name = name;
		this.complaintCount = complaintCount;
	}
	
}

