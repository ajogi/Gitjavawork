
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MobileNoValidationJUnit {
	@Before
	public void createBoInstance() {
		MobileNoValidationBO mb=new MobileNoValidationBO();
		
	
	}
	@Test
	public void testValidMobileNo() {
		String mobileNo="+919951999956";
	assertEquals("+919951999956", mobileNo);
		
	}
	/*@Test
	public void testInvalidMobileNo() {
		assertEquals("9951999956", "+919951999956");	
	}*/
}

