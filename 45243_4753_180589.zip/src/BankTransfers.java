public interface BankTransfers
{
    public String encrypt(String a);
    public String decrypt(String a);
}
