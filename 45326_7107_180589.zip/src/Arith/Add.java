package Arith;

public class Add {

	public static void main(String[] args) {
		int i=5493, j=247;
		int sum;
		sum = i+j;
      System.out.println("sum =" + sum);
	}
}
