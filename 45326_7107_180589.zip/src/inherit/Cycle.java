package inherit;

public interface Cycle {
	public abstract void balance();
		

}
