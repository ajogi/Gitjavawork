package inherit;
//An interface is 100%
public interface Transport {
	String transportName="Public Transport";
	
	void bookTicket();
	

}
