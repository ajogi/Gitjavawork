package inherit;

public class Train implements Transport{

	@Override
	public void bookTicket() {
		// TODO Auto-generated method stub
		
	}
}
