package inherit;

public class Traveldemo {
	public static void main(String[] args) {
		Bus b=new Bus();
		Train t=new Train();
		b.bookTicket();
		t.bookTicket();
	}

}
