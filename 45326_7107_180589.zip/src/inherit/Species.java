package inherit;

public class Species {
private boolean living;
//constructor
Species()
{
	living=true;
}

public void brethe()
{
	System.out.println("Can breathe");
}

}
