package inherit;

public class Bus implements Transport{

	@Override
	public void bookTicket() {
	 System.out.println("Bus ticket booked");
	 
		
	}

}
