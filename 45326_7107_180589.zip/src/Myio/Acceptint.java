package Myio;

import java.util.Scanner;

public class Acceptint {

	public static void main(String[] args) {
	
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the  i value:");
		int i= sc.nextInt();
		System.out.println(i);

}
	}
