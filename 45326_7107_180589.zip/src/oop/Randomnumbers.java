package oop;

import java.util.Scanner;
public class Randomnumbers {
	public static void main(String args[])
	{
	double d1 = 88.09;
	 double d2 = 55.66;
	 System.out.println("Ceiling of '" + d1 + "' = " + Math.ceil(d1));

	 System.out.println("Floor of '" + d1 + "' = " + Math.floor(d1));
	 
	 

	 System.out.println("Ceiling of '" + d2 + "' = " + Math.ceil(d2));

	 System.out.println("Floor of '" + d2 + "' = " + Math.floor(d2));
	}
	}