package ExceptionHandilig;

public class Exception {

}
