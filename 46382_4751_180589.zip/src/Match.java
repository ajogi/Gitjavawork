abstract class Match {
   
 private int currentScore;
 private float currentOver;
 private int target;
 
 void display()
 {
  
 }
 abstract float calculateRunRate();
 abstract int calculateBalls(); 
}