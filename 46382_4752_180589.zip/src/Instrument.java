

public abstract class Instrument {
	  String string;
	  public abstract void play();
	  {
	  	
	  	}
	  public String getString() {
	  	return string;
	  }
	  public void setString(String string) {
	  	this.string = string;
	  }


	  }
